import { Component } from '@angular/core';

@Component({
  selector: 'test-sub-page',
  templateUrl: './sub-page.component.html',
  styleUrl: './sub-page.component.scss',
})
export class SubPageComponent {}
