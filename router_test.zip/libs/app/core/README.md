# app-core

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test app-core` to execute the unit tests.
