import { Component } from '@angular/core';

@Component({
  selector: 'test-app-core',
  templateUrl: './app-core.component.html',
  styleUrl: './app-core.component.scss',
})
export class AppCoreComponent {}
